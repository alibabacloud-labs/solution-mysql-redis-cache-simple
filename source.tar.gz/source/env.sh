#!/bin/bash
export SG_REDISURL="r-xxxxxxx.redis.singapore.rds.aliyuncs.com"
export SG_REDIS_PASSWORD="test_redis:N1cetest"
export SG_DBHOST="rm-xxxxxxx.mysql.singapore.rds.aliyuncs.com"
export SG_DBNAME="test_mysql"
export SG_DBUSER="test_mysql"
export SG_DBUSERPW="N1cetest"